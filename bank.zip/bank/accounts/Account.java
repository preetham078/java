package bank.accounts;

public class Account {
    int accno;
    String type;
    double bal;

    public Account(int accno, String type, double bal)
    {
        this.accno = accno;
        this.type = type;
        this.bal = bal;
    }

    public void display()
    {
        System.out.println("Account Number: " + accno);
        System.out.println("Account Type: " + type);
        System.out.println("Account Balance: " + bal);
    }
   
}
