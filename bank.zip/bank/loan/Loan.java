package bank.loan;

public class Loan {
    int no;
    String Type;
    double amt;

    public Loan(int no, String Type, double amt)
    {
        this.no = no;
        this.Type = Type;
        this.amt = amt;
    }

    public void display()
    {
        System.out.println("Loan Number: " + no);
        System.out.println("Loan Type: " + Type);
        System.out.println("Loan Amount: " + amt);
    }
    
}
