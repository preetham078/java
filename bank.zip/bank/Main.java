package bank;
import bank.accounts.Account;
import bank.customer.Customer;
import bank.loan.Loan;

public class Main {
    public static void main(String[] args) {
        Customer c = new Customer(1, "a", "1234567890");
        Account acc = new Account(101, "Savings", 1000.0);
        Loan l = new Loan(1001, "Home", 50000.0);

        c.display();
        acc.display();
        l.display();
        
        
    }
}
