package bank.customer;

public class Customer 
{
    int customerid;
    String name;
    String contactno;

    public Customer(int customerid, String name, String contactno)
    {
        this.customerid = customerid;
        this.name = name;
        this.contactno = contactno;
    }

    public void display()
    {
        System.out.println("Customer Id: " + customerid);
        System.out.println("Customer Name: " + name);
        System.out.println("Contact Number: " + contactno);
    }
}